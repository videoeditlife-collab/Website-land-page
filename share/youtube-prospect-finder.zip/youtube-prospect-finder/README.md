# YouTube Prospect Finder

Finds YouTube creators who post regularly, have an audience that watches, and
sell something of their own (a course, coaching, a community or merch). Then
it narrows them down to a short list worth contacting.

**Read [`scraper/GUIDE.md`](scraper/GUIDE.md) first.** It covers setup, every
step, every filter, and how to judge the results.

## Quick start (on your own computer)

```bash
cd scraper
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m playwright install chromium

# 1. Discover channels from search terms
python youtube_scraper.py --search-file example_terms.txt --require-niche \
    --niche-file niche_broad.txt --sort-by date --per-term 12 \
    --save-discovered results/discovered_example.txt --output results/example_channels.csv

# 2. Drop anything already seen, split into batches of ~150
python split_new.py results/discovered_example.txt --prefix results/example_new

# 3. Score each batch (about 35-40 minutes per 150 channels)
python run_lead_generator.py results/example_new_1.txt results/example_1_leads.csv --descriptions 1 --resume

# 4. Keep the High-rated creators who sell something
python pick_sellers.py "results/example_*_leads.csv" --output results/example_picked.csv

# 5. Keep only the countries you want
python add_country.py results/example_picked.csv --countries-from "results/*_channels.csv" \
    --keep "United States,United Kingdom,Canada,Australia,New Zealand,Ireland,South Africa" \
    --output results/example_final.csv --missing results/need_country.txt
```

Then check every name by hand (GUIDE.md, step 7) before contacting anyone.

## Running it on GitHub Actions instead

Push this folder to a private GitHub repository, then turn on **Settings →
Actions → General → Workflow permissions → Read and write**. Use the
**Actions** tab to run "Scrape YouTube channels" (with `source = custom` and
`terms = your_terms.txt`) and "Lead generator". GUIDE.md section 14 has the
details.

## Folder layout

- `scraper/` holds the tools, search-term files, tests and the guide.
- `scraper/results/` is where output files go.
- `.github/workflows/` holds the GitHub Actions versions of each step.
